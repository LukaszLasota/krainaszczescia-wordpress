# WordPress MySQL database migration
#
# Generated: Saturday 20. March 2021 14:18 UTC
# Hostname: localhost
# Database: `local`
# URL: //new.krainaszczescia.edu.pl/
# Path: C:\\Users\\user\\Local Sites\\krainaszczescia\\app\\public
# Tables: wp_2_commentmeta, wp_2_comments, wp_2_links, wp_2_options, wp_2_postmeta, wp_2_posts, wp_2_term_relationships, wp_2_term_taxonomy, wp_2_termmeta, wp_2_terms, wp_3_commentmeta, wp_3_comments, wp_3_links, wp_3_options, wp_3_postmeta, wp_3_posts, wp_3_term_relationships, wp_3_term_taxonomy, wp_3_termmeta, wp_3_terms, wp_blogmeta, wp_blogs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_registration_log, wp_signups, wp_site, wp_sitemeta, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, nasze-atuty, page, post, wpcf7_contact_form, acf-field, acf-field-group, attachment, baner, banner, custom_css, customize_changeset, kariera, pdf-gocie, pdf-goscie, pdf-rodzice
# Protocol: http
# Multisite: true
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

